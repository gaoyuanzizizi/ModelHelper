from ModelHelper.Recognition.RecognitionModels.AbstractRecognitionModels import SarRecognitionModel
from ModelHelper.Common.CommonUtils import get


class Resnet50SarRecognitionModel(SarRecognitionModel):
    def __init__(self, **kwargs):
        kwargs['encoder'] = get('encoder', kwargs, 'Encoder')
        kwargs['decoder'] = get('decoder', kwargs, 'Decoder')
        super(Resnet50SarRecognitionModel, self).__init__(**kwargs)

    def forward(self, **kwargs):
        return super(Resnet50SarRecognitionModel, self).forward(**kwargs)


