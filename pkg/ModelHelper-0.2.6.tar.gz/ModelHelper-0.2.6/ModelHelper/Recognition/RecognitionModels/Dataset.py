from ModelHelper.Common.CommonUtils import get, get_valid
from torch.utils.data import Dataset
import cv2
import numpy as np
import os


class SarDataset(Dataset):
    def __init__(self, **kwargs):
        self.index_path = get_valid('index_path', kwargs)
        self.transforms = get('transforms', kwargs, None)
        self.recognition_transforms = get('recognition_transforms', kwargs, None)
        self.encoding = get('encoding', kwargs, 'utf-8')
        self.size = get('size', kwargs, (32, 256, 3))
        self.split = get('split', kwargs, ',')
        self.data_list = self.get_data_list()
        self.max_len = get('max_len', kwargs, 64)

    def __len__(self):
        return len(self.data_list)

    def get_data_list(self):
        data_list = list()
        folder = os.path.dirname(self.index_path)
        index = open(self.index_path, 'r', encoding=self.encoding)
        for line in index.readlines():
            line = line.replace('\n', '')
            line = line.strip()
            info = line.split(self.split)
            data = dict()
            img_name = info[0]
            img_path = os.path.join(folder, img_name)
            data['img_path'] = img_path
            data['label'] = info[1]
            data_list.append(data)
        return data_list

    def __padding(self, img):
        (height, width, channel) = self.size
        img_height = img.shape[0]
        img_width = img.shape[1]
        wh = width / height
        img_wh = img_width / img_height
        output = np.zeros(self.size, dtype=np.uint8)
        if img_wh > wh:
            ratio = width / img_width
            img_height = int(img_height * ratio)
            img = cv2.resize(img, (width, img_height))
            pad_top = int((height - img_height) / 2)
            output[pad_top:pad_top + img_height, :, :] = img
            valid_width = width
        else:
            ratio = height / img_height
            img_width = int(img_width * ratio)
            img = cv2.resize(img, (img_width, height))
            output[:, 0:img_width, :] = img
            valid_width = img_width
        return output, valid_width

    def __getitem__(self, idx):
        data = self.data_list[idx]
        img_path = data['img_path']
        label = data['label']
        img = cv2.imread(img_path)
        if self.recognition_transforms is not None:
            img = self.recognition_transforms(img)

        img, valid_width = self.__padding(img)
        if self.transforms is not None:
            img = self.transforms(img)
        mask_h = int(self.size[0]/8)
        mask_w = int(self.size[1]/4)

        mask = np.zeros((1, mask_h, mask_w))
        mask[:, :, :valid_width] = 1
        return img, label, mask
