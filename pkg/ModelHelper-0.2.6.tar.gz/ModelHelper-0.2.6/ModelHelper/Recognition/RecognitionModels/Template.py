from ModelHelper.Common.CommonModels.Template import AbstractTemplate
from ModelHelper.Common.CommonUtils import get, get_valid, generate_log
from ModelHelper.Common.CommonUtils.Wrapper import config, time_consume
from ModelHelper.Recognition.RecognitionModels.ModelFactory import RecognitionModelFactory
from ModelHelper.Recognition.RecognitionModels.Dataset import SarDataset
from ModelHelper.Common.CommonUtils.ImageAugmentation import RandomDistort, Denoise, Compose
import torch.optim as optim
from torchvision import transforms
import torch
import numpy as np
import torch.nn.functional as F
import os


class SarRecognitionTemplate(AbstractTemplate):
    def __init__(self, **kwargs):
        super(SarRecognitionTemplate, self).__init__(**kwargs)
        word_index_path = get_valid('word_index_path', kwargs)
        self.word2num, self.num2word = self.generate_dict(word_index_path)
        assert len(self.word2num) == len(self.num2word)
        self.class_num = len(self.word2num)
        self.max_len = get('max_len', kwargs, 64)

    @staticmethod
    def generate_dict(word_index_path, encoding='utf-8'):
        word_index = open(word_index_path, 'r', encoding=encoding)
        word2num = dict()
        num2word = dict()
        word2num['SOS'] = 0
        num2word[0] = 'SOS'
        num = 1
        for line in word_index.readlines():
            line = line.replace(' ', '')
            line = line.replace('\n', '')
            for idx in range(len(line)):
                word = line[idx]
                if word not in word2num.keys():
                    word2num[word] = num
                    num2word[num] = word
                    num += 1
        word_index.close()
        return word2num, num2word

    def encode(self, line_list, ignore_index):
        mx = 0
        num = len(line_list)
        new_line_list = list()
        for line in line_list:
            l = len(line)
            if l > self.max_len - 2:
                line = line[0:self.max_len - 2]
                mx = self.max_len - 2
            if l > mx:
                mx = l
            new_line_list.append(line)

        label = np.zeros((num, mx + 2), dtype=np.int32)
        if ignore_index:
            label -= 1

        row = 0
        for line in new_line_list:
            line = line.strip()
            line = line.replace(' ', '')
            col = 1
            for word in line:
                l = self.word2num[word]
                label[row, col] = l
                col += 1
            label[row, 0] = 0
            label[row, col] = 0
            row += 1
        return label

    def decode(self, preds_tensor):
        label_list = list()
        for pred in preds_tensor:
            pred = pred.cpu().numpy()
            label = ''
            for p in pred:
                p = int(p.argmax())
                if p != 0:
                    label += self.num2word[p]
                else:
                    break
            label_list.append(label)
        return label_list

    def init_model(self, **kwargs):
        model_factory = RecognitionModelFactory()
        kwargs['class_num'] = self.class_num
        return super(SarRecognitionTemplate, self).init_model(model_factory=model_factory, **kwargs)

    def init_trainloader(self, **kwargs):
        super(SarRecognitionTemplate, self).init_trainloader(**kwargs)
        train_transforms = get('train_transforms', kwargs, None)
        if train_transforms is None:
            train_transforms = transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
            ])
        kwargs['transforms'] = train_transforms

        train_recognition_transforms = get('train_recognition_transforms', kwargs)
        if train_recognition_transforms is None:
            distort_num = get('distort_num', kwargs, 10)
            distort_ratio = get('distort_ratio', kwargs, 0.1)
            train_recognition_transforms = Compose([
                RandomDistort(distort_num, distort_ratio)
            ])
        kwargs['recognition_transforms'] = train_recognition_transforms

        train_index = get_valid('train_index', kwargs)
        train_dataset = SarDataset(index_path=train_index, **kwargs)
        train_batch = get('train_batch', kwargs, 64)
        train_worker = get('train_worker', kwargs, 8)
        drop_last = get('drop_last', kwargs, True)
        shuffle = get('shuffle', kwargs, True)
        train_loader = torch.utils.data.DataLoader(train_dataset,
                                                   batch_size=self.get_batch_size(train_batch),
                                                   num_workers=train_worker,
                                                   drop_last=drop_last,
                                                   shuffle=shuffle)
        train_data_num = len(train_dataset)
        print('Analyse train index: {}, train data num: {}!'.format(train_index, train_data_num))
        return train_loader

    def init_testloader(self, **kwargs):
        super(SarRecognitionTemplate, self).init_testloader(**kwargs)
        test_transforms = get('test_transforms', kwargs, None)
        if test_transforms is None:
            test_transforms = transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
            ])
        kwargs['transforms'] = test_transforms

        test_recognition_transforms = get('test_recognition_transforms', kwargs)
        if test_recognition_transforms is None:
            blur_kernel = get('blur_kernel', kwargs, (3, 3))
            blur_sigma = get('blur_sigma', kwargs, 1)
            enhance_ratio = get('enhance_ratio', kwargs, 2)
            test_recognition_transforms = Compose([
                Denoise(blur_kernel, blur_sigma, enhance_ratio)
            ])
        kwargs['recognition_transforms'] = test_recognition_transforms

        test_index = get_valid('test_index', kwargs)
        test_dataset = SarDataset(index_path=test_index, **kwargs)

        test_batch = get('test_batch', kwargs, 64)
        test_worker = get('test_worker', kwargs, 8)
        test_loader = torch.utils.data.DataLoader(test_dataset,
                                                  batch_size=self.get_batch_size(test_batch),
                                                  num_workers=test_worker)
        test_data_num = len(test_dataset)
        print('Analyse test index: {}, test data num: {}!'.format(test_index, test_data_num))
        return test_loader

    def init_optimizer(self, **kwargs):
        model = get_valid('model', kwargs)
        lr = get('lr', kwargs, 1)
        return optim.Adadelta(model.parameters(), lr=lr)

    def init_criterion(self, **kwargs):
        super(SarRecognitionTemplate, self).init_criterion(**kwargs)
        return F.cross_entropy

    @time_consume
    def train_model(self, **kwargs):
        model = get_valid('model', kwargs)
        model.train()
        optimizer = get_valid('optimizer', kwargs)
        epoch = get_valid('epoch', kwargs)
        criterion = get_valid('criterion', kwargs)
        train_loader = get_valid('train_loader', kwargs)
        test_mini_batch = get('test_mini_batch', kwargs, True)
        mini_batch_step = get('mini_batch_step', kwargs, 10)
        total_loss = 0
        iter_num = len(train_loader)
        if iter_num == 0:
            raise RuntimeError('training data num < batch num!')
        for batch_idx, (image, label, mask) in enumerate(train_loader):
            target = self.encode(label, False)
            target = torch.from_numpy(target)
            target = target.long()

            target_cp = self.encode(label, True)
            target_cp = torch.from_numpy(target_cp)
            target_cp = target_cp.long()

            if self.gpu is not None:
                image = image.cuda()
                mask = mask.cuda()
                target = target.cuda()
                target_cp = target_cp.cuda()

            output = model(image=image, target=target, mask=mask)
            output = output.contiguous().view(-1, self.class_num)
            target_cp = target_cp[:, 1:].contiguous().view(-1)

            loss = criterion(output, target_cp, ignore_index=-1)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_loss += loss.data.item()
            if test_mini_batch:
                if batch_idx % mini_batch_step == 0 and batch_idx != 0:
                    print('Train, {}th mini batch, loss: {}!'.format(batch_idx, loss.data.item()))

        avg_loss = total_loss / iter_num
        log = generate_log(epoch=epoch,
                           name='Train',
                           avg_loss=avg_loss)
        return log, avg_loss

    @staticmethod
    def compute_acc(pred_list, label_list):
        assert len(pred_list) == len(label_list)
        total = len(pred_list)
        correct = 0
        for idx in range(total):
            pred = pred_list[idx]
            label = label_list[idx]
            if pred == label:
                correct += 1
        return correct / total, correct, total

    @time_consume
    def test_model(self, **kwargs):
        model = get_valid('model', kwargs)
        model.eval()
        epoch = get_valid('epoch', kwargs)
        criterion = get_valid('criterion', kwargs)
        test_loader = get_valid('test_loader', kwargs)
        total_loss = 0
        iter_num = len(test_loader)
        total_correct = 0
        total_pred = 0

        with torch.no_grad():
            for batch_idx, (image, label, mask) in enumerate(test_loader):
                target = self.encode(label, False)
                target = torch.from_numpy(target)
                target = target.long()

                target_cp = self.encode(label, True)
                target_cp = torch.from_numpy(target_cp)
                target_cp = target_cp.long()

                if self.gpu is not None:
                    image = image.cuda()
                    target = target.cuda()
                    mask = mask.cuda()
                    target_cp = target_cp.cuda()

                output = model(image=image, target=target, mask=mask)

                pred_label = self.decode(output)
                acc, correct, pred_num = self.compute_acc(pred_label, label)

                total_correct += correct
                total_pred += pred_num

                output = output.contiguous().view(-1, self.class_num)
                target_cp = target_cp[:, 1:].contiguous().view(-1)

                loss = criterion(output, target_cp, ignore_index=-1)
                total_loss += loss.data.item()

        acc = total_correct / total_pred
        avg_loss = total_loss / iter_num
        log = generate_log(epoch=epoch,
                           name='Test',
                           avg_loss=avg_loss)
        return log, avg_loss, acc

    @time_consume
    def eval_model(self, **kwargs):
        super(SarRecognitionTemplate, self).eval_model(**kwargs)

    def load_model(self, **kwargs):
        return super(SarRecognitionTemplate, self).load_model(**kwargs)

    def save_model(self, **kwargs):
        return super(SarRecognitionTemplate, self).save_model(**kwargs)

    @config
    def run(self, **kwargs):
        model = self.init_model(**kwargs)

        train_loader = self.init_trainloader(model=model, **kwargs)
        test_loader = self.init_testloader(model=model, **kwargs)

        optimizer = self.init_optimizer(model=model, **kwargs)
        criterion = self.init_criterion(**kwargs)

        output_folder = get_valid('output_folder', kwargs)
        ckpt_folder = os.path.join(output_folder, 'ckpt')
        if not os.path.exists(ckpt_folder):
            os.makedirs(ckpt_folder)
        log_path = os.path.join(output_folder, 'log.txt')
        checkpoint = get('checkpoint', kwargs)
        if checkpoint is not None:
            model, start_epoch, best_acc, min_loss = self.load_model(model=model, **kwargs)
        else:
            start_epoch = 0
            best_acc = 0
            min_loss = 999999

        epoch_num = get('epoch_num', kwargs, 1000)
        do_test = get('do_test', kwargs, True)
        test_step = get('test_step', kwargs, 1)
        save_by_loss = get('save_by_loss', kwargs, False)
        for epoch in range(start_epoch, epoch_num):
            train_log, train_loss = self.train_model(train_loader=train_loader,
                                                     optimizer=optimizer,
                                                     criterion=criterion,
                                                     model=model,
                                                     epoch=epoch,
                                                     **kwargs)
            log = open(log_path, 'a', encoding=self.encoding)
            log.write(train_log)
            log.close()
            print(train_log)

            if not do_test:
                if epoch % test_step == 0 and epoch != 0:
                    self.save_model(model=model,
                                    ckpt_folder=ckpt_folder,
                                    epoch=epoch,
                                    loss=train_loss
                                    )
            else:
                if epoch % test_step == 0 and epoch != 0:
                    test_log, test_loss, acc = self.test_model(test_loader=test_loader,
                                                               criterion=criterion,
                                                               model=model,
                                                               epoch=epoch,
                                                               **kwargs)
                    if save_by_loss:
                        if test_loss < min_loss:
                            min_loss = test_loss
                            self.save_model(model=model,
                                            ckpt_folder=ckpt_folder,
                                            epoch=epoch,
                                            loss=test_loss,
                                            eval_type='accuracy',
                                            eval_score=acc)
                    else:
                        if acc > best_acc:
                            best_acc = acc
                            self.save_model(model=model,
                                            ckpt_folder=ckpt_folder,
                                            epoch=epoch,
                                            loss=test_loss,
                                            eval_type='accuracy',
                                            eval_score=acc)

                    test_log += 'Eval: acc: {}\n'.format(acc)
                    log = open(log_path, 'a', encoding=self.encoding)
                    log.write(test_log)
                    log.close()
                    print(test_log)
